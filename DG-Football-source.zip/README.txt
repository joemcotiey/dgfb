DG Football - how to get the installable .exe

OPTION A (on a Windows PC)
1. Install Node.js LTS from https://nodejs.org
2. Double-click build-installer.bat
3. Installer appears in dist\  ->  "DG Football Setup 1.0.0.exe"

OPTION B (no tools on your PC): free GitHub cloud build
1. Create a free GitHub account, make a new repository, upload all files of this folder (including the .github folder)
2. Open the Actions tab -> "Build DG Football installer" -> Run workflow
3. When finished, download the "DG-Football-Installer" artifact (contains the .exe)

Quick test without installing: npm install, then npm start.
Modes: Exhibition, or Season (press Y / M on the menu): 19 matches, full 20-club table.
