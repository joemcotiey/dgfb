@echo off
echo Building DG Football installer (needs Node.js from nodejs.org)...
call npm install
call npm run dist
echo.
echo Done. Your installer is in the "dist" folder: DG Football Setup 1.0.0.exe
pause
